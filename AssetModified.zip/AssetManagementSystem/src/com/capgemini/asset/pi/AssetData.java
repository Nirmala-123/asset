package com.capgemini.asset.pi;
import java.sql.SQLException;
import java.util.*;

import com.capgemini.asset.bean.AssetBean;
import com.capgemini.asset.bean.AssetRequestBean;
import com.capgemini.asset.bean.AssetRequestFormBean;
import com.capgemini.asset.bean.UserBean;
import com.capgemini.asset.exception.AssetException;
import com.capgemini.asset.service.*;
public class AssetData {

	public static void main(String[] args) throws Exception{
		Scanner s=new Scanner(System.in);
		String usernameId,password,assetName;
		boolean check=true;
		IAssetInterface ie=new AssetImpl();
		UserBean us=new UserBean();
		AssetBean as=new AssetBean();
		int option;
		
		
		//Authentication of User name and Password
		
		do{
			
			do{
				System.out.println("Enter Name/User Id");
				usernameId=s.next();
			}while(!(ie.isValidUsername(usernameId)));
		
			do{
				System.out.println("Enter Password");
				password=s.next();
			}while(!(ie.isValidPassword(password)));
			us.setUserNameId(usernameId);
			us.setPassword(password);
	}while(!ie.dataAuthentication(us));
		
		
		//Admin Tasks
		
		if(us.getUserType().equals("ADMIN")){
			System.out.println("1.Add New Asset \n 2.Modify Asset details \n 3.View Asset Requests");
			System.out.println("Enter your option:");
			option=s.nextInt();
			switch(option){
				case 1:	
						System.out.println("Enter Asset Id:");
						as.setAssetId(s.nextLong());
						System.out.println("Enter Asset Name:");
						as.setAssetName(s.next());
						System.out.println("Enter Asset Description:");
						as.setAssetDes(s.next());
						System.out.println("Enter Asset Quantity:");
						as.setQuantity(s.nextInt());
						System.out.println("Enter Asset Status:");
						as.setStatus(s.next());
						try{
						ie.addNewAsset(as);
						}
						catch(AssetException a){
							System.out.println(a);
						}
						catch(SQLException s1){
							System.out.println(s1.getMessage());
						}
						break;
				case 2:
						System.out.println("Enter the Asset Id for which you want to modify details.");
						long oldAssetId=s.nextLong();
						System.out.println("Enter New Asset Id:");
						as.setAssetId(s.nextLong());
						System.out.println("Enter New Asset Name:");
						as.setAssetName(s.next());
						System.out.println("Enter Asset Description:");
						as.setAssetDes(s.next());
						System.out.println("Enter Asset Quantity:");
						as.setQuantity(s.nextInt());
						System.out.println("Enter Asset Status:");
						as.setStatus(s.next());
						try{
						ie.modifyAssetDetails(as,oldAssetId);
						}
						catch(Exception e){
							System.out.println(e);
						}
						
						break;
					
				case 3:
					ArrayList<AssetRequestBean> al=null;
						System.out.println("Enter the Asset Id for which you want to check request:");
						int  assetId=s.nextInt();
						try{
							 al=ie.viewAssetRequestDetails(assetId);
						}
						catch(Exception e){
							System.out.println(e);
						}
						System.out.println("Request-Id Asset-Id EmpNo AssetName AssetDescription  Quantity");
						for(int i=0;i<al.size();i++){
							AssetRequestBean ar=al.get(i);
							System.out.println(ar.getRequestId()+"    "+ar.getAssetId()+"    "+ar.getEmpid()+"    "+ar.getAssetName()+"      "+ar.getAssetDes()+"     "+ar.getQuantity());
						if(ie.isValidQuantity(ar)){
							System.out.println("1.Accept\n2.Reject");
							int ch=s.nextInt();
							if(ch==1){
								System.out.println(ie.modifyStatus("Accept",ar));
							}
							else if(ch==2){
								System.out.println(ie.modifyStatus("Reject",ar));
							}
						}
						else
						{
							System.out.println("Asset is Not Available");
							//ie.modifyStatus("Reject",ar);
						}
						break;
			}		
		}			
		}
		
		
		//Manager Tasks
		
		else if(us.getUserType().equals("MANAGER")){
			ArrayList<String> al=null;
			System.out.print("1.Raise a new request\n2.View Status of Request");
			System.out.println("Enter your option:");
			option=s.nextInt();
			switch(option){
			case 1:
				AssetRequestFormBean assetRequest=new AssetRequestFormBean();
				System.out.println("\n1.Enter Employee Id");
				int empId=s.nextInt();
				try{
				al=ie.viewAssets();
				}
				catch(Exception a)
				{
					System.out.println(a);
				}
				System.out.println("Assets");
				System.out.println("______________");
				for(Object o:al){
				System.out.println(o);
				}
				do{
				System.out.println("\n2.Enter Asset Name:");
				 assetName=s.next();
				}while(!ie.isValidAssetName(al, assetName));
				System.out.println("\n3.Enter Asset Description with _:");
				String assetDes=s.next();
				System.out.println("\n4.Purpose:");
				String assetPurpose=s.next();
				System.out.println("\n5.Enter Asset Quantity:");
				int quan=s.nextInt();
				assetRequest.setEmpId(empId);
				assetRequest.setAssetName(assetName);
				assetRequest.setAssetDes(assetDes);
				assetRequest.setAssetPurpose(assetPurpose);
				assetRequest.setQuan(quan);
				try{
				System.out.println("Your request is raised with Request Id:"+ie.raiseRequest(assetRequest));
				}
				catch(Exception e){
					e.printStackTrace();
				}
				break;
			
			
			case 2:
				ArrayList<AssetRequestBean> request=null;
				System.out.println("Enter request Id:");
				int requestId=s.nextInt();
				try{
				request=ie.viewRequestDetails(requestId);	
				
				}
				catch(Exception e){
					System.out.println(e);
				}
				for(int i=0;i<request.size();i++){
					AssetRequestBean ar=request.get(i);
					System.out.println(ar.getRequestId()+"   "+ar.getAssetId()+"   "+ar.getAssetName()+"   "+ar.getRequestStatus());
				}

				
				
			}
		}
			
		
		
	}
}
